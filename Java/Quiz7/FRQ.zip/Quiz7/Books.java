package Quiz7;

public class Books extends Materials {

    public Books(String bookname, String PrimaryC, int pages){
        super(bookname, PrimaryC, pages);

    }

    @Override
    public void print_msg(){
        System.out.println("This is just book !!");
        System.out.println("Book name: " + getBookname() + "\nBY: " + getPrimaryC() + "\nPages: "+ getPage() + " Pages");
        System.out.println();
    }
}
