package Quiz7;

public class MaterialDriver {
    public static void main(String[] args) {
        Textbooks t1 = new Textbooks("Java Foundation", "John something", 1500);
        Books b1 = new Books("Three tiger", "Alex Lee", 823);
        Journals j1 = new Journals("Daily life", "Derrick", 254);
        Meagzines m1 = new Meagzines("Times", "Helo D", 68);
        Novel n1 = new Novel("LOST", "Hunter Tsai", 1020);

        t1.print_msg();
        b1.print_msg();
        j1.print_msg();
        m1.print_msg();
        n1.print_msg();
    }
}
