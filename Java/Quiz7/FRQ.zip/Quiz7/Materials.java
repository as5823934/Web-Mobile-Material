package Quiz7;

public abstract class Materials {
    private int page;
    private String primaryC;
    private String bookname;

    public Materials(String bookname, String primaryC, int pages){
        this.bookname = bookname;
        this.primaryC = primaryC;
        this.page = pages;
    }

    public int getPage() {
        return page;
    }

    public String getBookname() {
        return bookname;
    }

    public String getPrimaryC() {
        return primaryC;
    }

    public abstract void print_msg();
}
