package Quiz7;

public class Journals extends Materials {

    public Journals(String bookname, String PrimaryC, int pages){
        super(bookname, PrimaryC, pages);

    }
    @Override
    public void print_msg(){
        System.out.println("This is technical journals !!");
        System.out.println("Book name: " + getBookname() + "\nBY: " + getPrimaryC() + "\nPages: "+ getPage() + " Pages");
        System.out.println();
    }
}
