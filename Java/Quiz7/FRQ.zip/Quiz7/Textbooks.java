package Quiz7;

public class Textbooks extends Materials {

    public Textbooks(String bookname, String PrimaryC, int pages){
        super(bookname, PrimaryC, pages);
    }

    @Override
    public void print_msg(){
        System.out.println("This is school textbook !!");
        System.out.println("Book name: " + getBookname() + "\nBY: " + getPrimaryC() + "\nPages: "+ getPage() + " Pages");
        System.out.println();
    }
}
